package com.example.groupf9_hw03;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CitiesListAdapter extends ArrayAdapter<Data.City> {

    public CitiesListAdapter(@NonNull Context context, int resource, @NonNull List<Data.City> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_cities_list, parent, false);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.textViewCity = convertView.findViewById(R.id.textViewCity);
            convertView.setTag(viewHolder);
        }
        Data.City cities = getItem(position);
        ViewHolder viewHolder = (ViewHolder)convertView.getTag();

        //set text
        viewHolder.textViewCity.setText(cities.getCity() + ", " + cities.getCountry());

        //return view
        return convertView;
    }

    private static class ViewHolder {
        TextView textViewCity, textViewCountry;
    }
}

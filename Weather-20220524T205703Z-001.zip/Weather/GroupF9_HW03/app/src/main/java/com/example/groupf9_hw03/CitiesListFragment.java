package com.example.groupf9_hw03;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class CitiesListFragment extends Fragment {

    private static final String ARG_PARAM_CITY = "ARG_PARAM_CITY";
    private static final String ARG_PARAM_COUNTRY = "ARG_PARAM_COUNTRY";
    private static final String ARG_PARAM_DATA = "ARG_PARAM_DATA";
    public DataListener listener;

    TextView textViewCity, textViewCountry;
    ArrayAdapter<String> adapter;
    ListView listView;

    private String city;
    private String country;
    //private Data.City selectedData;
    private String selectedData;

    public CitiesListFragment() {
        // Required empty public constructor
    }

    public static CitiesListFragment newInstance(Data.City data) {
        CitiesListFragment fragment = new CitiesListFragment();
        Bundle args = new Bundle();
//        args.putString(ARG_PARAM_CITY, city);
//        args.putString(ARG_PARAM_COUNTRY, country);
        args.putSerializable(ARG_PARAM_DATA, data);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof DataListener) {
            listener = (DataListener) context;
        } else {
            //"Must implement CitiesList Interface"
            throw new RuntimeException(context.getString(R.string.RunTimeExceptionCitiesList));
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
//            city = getArguments().getString(ARG_PARAM_CITY);
//            country = getArguments().getString(ARG_PARAM_COUNTRY);
//            selectedData = (Data.City) getArguments().getSerializable(ARG_PARAM_DATA);
            selectedData = getArguments().getString(ARG_PARAM_DATA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cities_list, container, false);

        List<Data.City> dataListNew = Data.cities;

        ListView listView = view.findViewById(R.id.listView);
        CitiesListAdapter adapter = new CitiesListAdapter(getContext(), R.layout.list_item_cities_list, dataListNew);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Data.City clickedData = adapter.getItem(position);
                listener.onClickedData(clickedData);
            }
        });

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        //Cities
        getActivity().setTitle(R.string.citiesListTitle);
    }

    public interface DataListener {
        void onClickedData(Data.City clickedData);
    }

}
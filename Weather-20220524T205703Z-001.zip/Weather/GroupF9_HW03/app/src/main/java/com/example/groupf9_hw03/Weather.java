package com.example.groupf9_hw03;

public class Weather {

    String description;
    String dt_text;
    String icon;
    double temperature;
    double tempMin;
    double tempMax;
    double windDegree;
    double windSpeed;
    int hum;
    String cloudy;

    public Weather() {

    }

    public Weather(String description, String dt_text, String icon, double temperature, double tempMin, double tempMax, double windDegree, double windSpeed, int hum, String cloudy) {
        this.description = description;
        this.dt_text = dt_text;
        this.icon = icon;
        this.temperature = temperature;
        this.tempMin = tempMin;
        this.tempMax = tempMax;
        this.windDegree = windDegree;
        this.windDegree = windDegree;
        this.windSpeed = windSpeed;
        this.hum = hum;
        this.cloudy = cloudy;
    }

    @Override
    public String toString() {
        return "Weather{" +
                "description='" + description + '\'' +
                ", dt_text='" + dt_text + '\'' +
                ", icon='" + icon + '\'' +
                ", temperature=" + temperature +
                ", tempMin=" + tempMin +
                ", tempMax=" + tempMax +
                ", windDegree=" + windDegree +
                ", windSpeed=" + windSpeed +
                ", hum=" + hum +
                ", cloudy='" + cloudy + '\'' +
                '}';
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDt_text() {
        return dt_text;
    }

    public void setDt_text(String dt_text) {
        this.dt_text = dt_text;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getTempMin() {
        return tempMin;
    }

    public void setTempMin(double tempMin) {
        this.tempMin = tempMin;
    }

    public double getTempMax() {
        return tempMax;
    }

    public void setTempMax(double tempMax) {
        this.tempMax = tempMax;
    }

    public double getWindDegree() {
        return windDegree;
    }

    public void setWindDegree(double windDegree) {
        this.windDegree = windDegree;
    }

    public double getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(double windSpeed) {
        this.windSpeed = windSpeed;
    }

    public int getHum() {
        return hum;
    }

    public void setHum(int hum) {
        this.hum = hum;
    }

    public String getCloudy() {
        return cloudy;
    }

    public void setCloudy(String cloudy) {
        this.cloudy = cloudy;
    }
}
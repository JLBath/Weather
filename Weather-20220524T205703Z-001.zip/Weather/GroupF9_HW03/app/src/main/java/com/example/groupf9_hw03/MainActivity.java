package com.example.groupf9_hw03;
//GroupF9_HW03
//Jacob Mack
//Jenna Bath
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity implements CitiesListFragment.DataListener, CurrentWeatherFragment.ForecastListener {
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragmentContainerView, new CitiesListFragment())
                .commit();
    }

    @Override
    public void onClickedData(Data.City clickedData) {
        //clicking data should go to the appropriate current weather screen - the screen after cities list via clicked list item
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, CurrentWeatherFragment.newInstance(clickedData))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onClickedForecast(Data.City clickedData) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, WeatherForecastFragment.newInstance(clickedData))
                .addToBackStack(null)
                .commit();
    }

}
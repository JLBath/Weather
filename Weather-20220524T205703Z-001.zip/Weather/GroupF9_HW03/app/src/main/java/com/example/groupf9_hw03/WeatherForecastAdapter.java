package com.example.groupf9_hw03;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.List;

public class WeatherForecastAdapter extends ArrayAdapter<Forecast> {

    public WeatherForecastAdapter(@NonNull Context context, int resource, @NonNull List<Forecast> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_weather_forecast, parent, false);
        }
        Forecast forecast = getItem(position);

        TextView textViewDate = convertView.findViewById(R.id.textViewDate);
        TextView textViewDescriptionF = convertView.findViewById(R.id.textViewDescriptionF);
        TextView textViewHumidityF = convertView.findViewById(R.id.textViewHumidityF);
        TextView textViewTempF = convertView.findViewById(R.id.textViewTemperatureF);
        TextView textViewTempMaxF = convertView.findViewById(R.id.textViewTemperatureMaxF);
        TextView textViewTempMinF = convertView.findViewById(R.id.textViewTemperatureMinF);
        ImageView ivIcon = convertView.findViewById(R.id.ivIconForecast);

        textViewDate.setText(forecast.getTime());
        textViewDescriptionF.setText(forecast.getDesc());
        textViewHumidityF.setText(String.valueOf(forecast.getHum()) + "%");
        textViewTempF.setText(String.valueOf(forecast.getTemperature()) + "F");
        textViewTempMaxF.setText(String.valueOf(forecast.getTempMax()) + "F");
        textViewTempMinF.setText(String.valueOf(forecast.getTempMin()) + "F");

        Picasso.get().load("https://openweathermap.org/img/wn/" + forecast.getIcon() + ".png").into(ivIcon);

        //return view
        return convertView;
    }

    private static class ViewHolder {
        TextView textViewDate, textViewTempF, textViewTemperatureMaxF,
                textViewTemperatureMinF, textViewHumidityF, textViewDescriptionF;
        Forecast forecast;
    }
}


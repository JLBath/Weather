package com.example.groupf9_hw03;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class WeathersResponse {
    String list;
    ArrayList<Forecast> forecasts;

    @Override
    public String toString() {
        return "WeathersResponse{" +
                "forecastWeatherLists=" + list + '}';
    }
}

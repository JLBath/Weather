package com.example.groupf9_hw03;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link WeatherForecastFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WeatherForecastFragment extends Fragment {

    private static final String ARG_PARAM_DATA = "param1";

    private String mParam1;

    private final OkHttpClient client = new OkHttpClient();
    private Data.City selectedData;
    TextView textViewCityCountryForecast;
    ListView listView;
    ArrayList<Forecast> forecasts = new ArrayList<>();

    WeatherForecastAdapter adapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    TextView textViewTemperature, textViewTemperatureMax, textViewTemperatureMin,
            textViewDescription, textViewHumidity, textViewDate;
    ImageView ivForecast;

    public WeatherForecastFragment() {
        // Required empty public constructor
    }

    public static WeatherForecastFragment newInstance(Data.City data) {
        WeatherForecastFragment fragment = new WeatherForecastFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM_DATA, data);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            selectedData = (Data.City) getArguments().getSerializable(ARG_PARAM_DATA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather_forecast, container, false);


        //city country display

        textViewCityCountryForecast = view.findViewById(R.id.textViewCityCountryForecast);

        setName();

        //loadData();

        //load data
        String city = selectedData.getCity();
        String country = selectedData.getCountry();
        String unit = "&units=imperial";
        String Key = "12bb4cdac4f171ba6feb5336bc030e93";
        String url = "https://api.openweathermap.org/data/2.5/forecast?q=" + city + "," + country + unit + "&appid=" + Key;

        Request request = new Request.Builder()
                //.url("https://api.openweathermap.org/data/2.5/forecast?q=London,us&units=imperial&appid=12bb4cdac4f171ba6feb5336bc030e93")
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                Log.d(TAG, "onResponse: Thread ID " + Thread.currentThread().getId());
                if (response.isSuccessful()) {
                    try {

                        JSONObject JSONResponse = new JSONObject(response.body().string());
                        JSONArray JSONList = JSONResponse.getJSONArray("list");

                        for(int i = 0; i < JSONList.length(); i++){
                            Forecast fc = new Forecast();
                            JSONObject item = JSONList.getJSONObject(i);
                            JSONObject mainThing = item.getJSONObject("main");
                            JSONArray weather = item.getJSONArray("weather");
                            JSONObject weatherObject = weather.getJSONObject(0);

                            String description = weatherObject.getString("description");
                            String icon = weatherObject.getString("icon");
                            String time = item.getString("dt_txt");
                            double temperature = mainThing.getDouble("temp");
                            double tempMin = mainThing.getDouble("temp_min");
                            double tempMax = mainThing.getDouble("temp_max");
                            int humi = mainThing.getInt("humidity");

                            fc.setIcon(icon);
                            fc.setDesc(description);
                            fc.setTime(time);
                            fc.setTemperature(temperature);
                            fc.setTempMin(tempMin);
                            fc.setTempMax(tempMax);
                            fc.setHum(humi);

                            Log.d(TAG, "onResponse: getTime " + time);

                            forecasts.add(fc);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            listView = view.findViewById(R.id.listViewF);
                            adapter = new WeatherForecastAdapter(getContext(), R.layout.list_item_weather_forecast, forecasts);
                            listView.setAdapter(adapter);
                        }
                    });
                } else {
                    ResponseBody responseBody = response.body();
                    String body = responseBody.string();
                    Log.d(TAG, "onResponse: " + body);
                }

            }
        });
        return view;
    }

    void loadData() {
//        String city = selectedData.getCity();
//        String country = selectedData.getCountry();
//        String unit = "&units=imperial";
//        String Key = "12bb4cdac4f171ba6feb5336bc030e93";
//        String url = "https://api.openweathermap.org/data/2.5/forecast?q=" + city + "," + country + unit + "&appid=" + Key;
//
//        Request request = new Request.Builder()
//                //.url("https://api.openweathermap.org/data/2.5/forecast?q=London,us&units=imperial&appid=12bb4cdac4f171ba6feb5336bc030e93")
//                .url(url)
//                .build();
//        client.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(@NonNull Call call, @NonNull IOException e) {
//                e.printStackTrace();
//            }
//
//            @Override
//            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
//                Log.d(TAG, "onResponse: Thread ID " + Thread.currentThread().getId());
//                if (response.isSuccessful()) {
//                    try {
//                        JSONObject JSONResponse = new JSONObject(response.body().string());
//                        JSONArray JSONList = JSONResponse.getJSONArray("list");
//
//                        for(int i = 0; i < JSONList.length(); i++){
//                            Forecast fc = new Forecast();
//                            JSONObject item = JSONList.getJSONObject(i);
//                            JSONObject mainThing = item.getJSONObject("main");
//                            JSONArray weather = item.getJSONArray("weather");
//                            JSONObject weatherObject = weather.getJSONObject(0);
//
//                            String description = weatherObject.getString("description");
//                            String icon = weatherObject.getString("icon");
//                            String time = item.getString("dt_text");
//                            double temperature = mainThing.getDouble("temp");
//                            double tempMin = mainThing.getDouble("temp_min");
//                            double tempMax = mainThing.getDouble("temp_max");
//                            int humi = mainThing.getInt("humidity");
//
//                            fc.setIcon(icon);
//
//
//
//
//                        }
//
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//
//                    getActivity().runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//
//                            adapter = new WeatherForecastAdapter(getContext(), R.layout.list_item_weather_forecast, arrayList)
//                            .setAdapter(adapter);
//                        }
//                    });
//                } else {
//                    ResponseBody responseBody = response.body();
//                    String body = responseBody.string();
//                    Log.d(TAG, "onResponse: " + body);
//                }
//
//            }
//        });

    }


    void setName(){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(!(textViewCityCountryForecast.getText().toString().isEmpty()) || selectedData.getCity() != null || selectedData != null) {
                    textViewCityCountryForecast.setText(selectedData.getCity() + ", " + selectedData.getCountry());
                }
            }
        });
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        //Weather Forecast
        getActivity().setTitle(R.string.weatherForecastTitle);
    }


}
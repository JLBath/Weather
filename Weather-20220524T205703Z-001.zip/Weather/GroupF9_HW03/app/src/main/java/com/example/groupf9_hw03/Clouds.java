package com.example.groupf9_hw03;

public class Clouds {
    String all;

    public String getAll() {
        return all;
    }

    public void setAll(String all) {
        this.all = all;
    }
}
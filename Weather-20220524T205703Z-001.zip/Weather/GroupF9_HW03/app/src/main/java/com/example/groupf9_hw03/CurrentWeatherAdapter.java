package com.example.groupf9_hw03;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CurrentWeatherAdapter extends ArrayAdapter<Data.City> {
    ArrayList<Weather> weathers;

    public CurrentWeatherAdapter(@NonNull Context context, int resource, ArrayList<Weather> weathers) {
        super(context, resource);
        this.weathers = weathers;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_cities_list, parent, false);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.textViewTemperature = convertView.findViewById(R.id.textViewTemperature);
            viewHolder.textViewTemperatureMax = convertView.findViewById(R.id.textViewTemperatureMax);
            viewHolder.textViewTemperatureMin = convertView.findViewById(R.id.textViewTemperatureMin);
            viewHolder.textViewDescription = convertView.findViewById(R.id.textViewDescription);
            viewHolder.textViewHumidity = convertView.findViewById(R.id.textViewHumidity);
            viewHolder.textViewWindSpeed = convertView.findViewById(R.id.textViewWindSpeed);
            viewHolder.textViewWindDegree = convertView.findViewById(R.id.textViewWindDegree);
            viewHolder.textViewCloudiness = convertView.findViewById(R.id.textViewCloudiness);
            convertView.setTag(viewHolder);
        }
        Data.City cities = getItem(position);
        ViewHolder viewHolder = (ViewHolder)convertView.getTag();

        //set text
        viewHolder.textViewTemperature.setText(cities.getCity());
        viewHolder.textViewTemperatureMax.setText(cities.getCountry());
        viewHolder.textViewTemperatureMin.setText(cities.getCity());
        viewHolder.textViewDescription.setText(cities.getCountry());
        viewHolder.textViewHumidity.setText(cities.getCity());
        viewHolder.textViewWindSpeed.setText(cities.getCountry());
        viewHolder.textViewWindDegree.setText(cities.getCity());
        viewHolder.textViewCloudiness.setText(cities.getCountry());

        //return view
        return convertView;
    }

    private static class ViewHolder {
        TextView textViewTemperature, textViewTemperatureMax, textViewTemperatureMin,
                textViewDescription, textViewHumidity, textViewWindSpeed, textViewWindDegree,
                textViewCloudiness;
    }
}

package com.example.groupf9_hw03;

public class Forecast {

    String desc;
    String icon;
    String time;
    double tempMin;
    double tempMax;
    double temperature;
    int hum;

    public Forecast() {

    }

    public Forecast(String desc, String icon, String time, double tempMin, double tempMax, double temperature, int hum) {
        this.desc = desc;
        this.icon = icon;
        this.time = time;
        this.tempMin = tempMin;
        this.tempMax = tempMax;
        this.temperature = temperature;
        this.hum = hum;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public double getTempMin() {
        return tempMin;
    }

    public void setTempMin(double tempMin) {
        this.tempMin = tempMin;
    }

    public double getTempMax() {
        return tempMax;
    }

    public void setTempMax(double tempMax) {
        this.tempMax = tempMax;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public int getHum() {
        return hum;
    }

    public void setHum(int hum) {
        this.hum = hum;
    }
}
package com.example.groupf9_hw03;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CurrentWeatherFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CurrentWeatherFragment extends Fragment {

    private static final String ARG_PARAM_DATA = "ARG_PARAM_DATA";

//    private String temperature, temperatureMax, temperatureMin, description, humidity,
//            windSpeed, windDegree, cloudiness;

    private Data.City selectedData;
    public ForecastListener listener;

    ArrayAdapter<String> adapter;

    Weather weather = new Weather();
    private String TAG = "DEMO";
    private final OkHttpClient client = new OkHttpClient();
    ListView listView;
    TextView textViewTemperature, textViewTemperatureMax, textViewTemperatureMin,
            textViewDescription, textViewHumidity, textViewWindSpeed, textViewWindDegree,
            textViewCloudiness, textViewCountryCurrent, textViewCityCurrent;
    ImageView ivIcon;
    Button button;

    public CurrentWeatherFragment() {
        // Required empty public constructor
    }

    public static CurrentWeatherFragment newInstance(Data.City data) {
        CurrentWeatherFragment fragment = new CurrentWeatherFragment();
        Bundle args = new Bundle();
//        args.putString(ARG_PARAM_DATA, data);
//        args.putString(ARG_PARAM2, param2);
        args.putSerializable(ARG_PARAM_DATA, data);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof ForecastListener) {
            listener = (ForecastListener) context;
        } else {
            //"Must implement CitiesList Interface"
            throw new RuntimeException(context.getString(R.string.RunTimeExceptionCitiesList));
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
            selectedData = (Data.City) getArguments().getSerializable(ARG_PARAM_DATA);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_current_weather, container, false);
        //data to set
        textViewTemperature = view.findViewById(R.id.textViewTemperatureVal);
        textViewTemperatureMax = view.findViewById(R.id.textViewTemperatureMaxVal);
        textViewTemperatureMin = view.findViewById(R.id.textViewTemperatureMinVal);
        textViewDescription = view.findViewById(R.id.textViewDescriptionVal);
        textViewHumidity = view.findViewById(R.id.textViewHumidityVal);
        textViewWindSpeed = view.findViewById(R.id.textViewWindSpeedVal);
        textViewWindDegree = view.findViewById(R.id.textViewWindDegreeVal);
        textViewCloudiness = view.findViewById(R.id.textViewCloudinessVal);
        //textViewCountryCurrent = view.findViewById(R.id.textViewCountryCurrent);
        textViewCityCurrent = view.findViewById(R.id.textViewCityCountry);
        ivIcon = view.findViewById(R.id.ivIcon);
        button = view.findViewById(R.id.buttonCheckF);

        //set data here with load data method
        setTitles();
        loadData();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String clickedData = selectedData.getCity();
                listener.onClickedForecast(selectedData);
            }
        });

        return view;
    }

    public void loadData() {
        String city = selectedData.getCity();
        String country = selectedData.getCountry();
        String unit = "&units=imperial";
        String Key = "12bb4cdac4f171ba6feb5336bc030e93";
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "," + country + unit + "&appid=" + Key;

        Request request = new Request.Builder()
                //.url("https://api.openweathermap.org/data/2.5/weather?q=Charlotte,US&appid=12bb4cdac4f171ba6feb5336bc030e93") //input api information here
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "onFailure: request failed");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                Log.d(TAG, "onResponse: Thread ID " + Thread.currentThread().getId());
                if (response.isSuccessful()) {


                    try {
                        JSONObject jsonResponse = new JSONObject(response.body().string());
                        JSONArray jsonArray = jsonResponse.getJSONArray("weather");
                        JSONObject jsonObjectWeather = jsonArray.getJSONObject(0);
                        String description = jsonObjectWeather.getString("description");
                        String icon = jsonObjectWeather.getString("icon");

                        JSONObject jsonObjectMain = jsonResponse.getJSONObject("main");
                        double temp = jsonObjectMain.getDouble("temp");
                        double temp_min = jsonObjectMain.getDouble("temp_min");
                        double temp_max = jsonObjectMain.getDouble("temp_max");
                        int humidity = jsonObjectMain.getInt("humidity");

                        JSONObject jsonObjectWind = jsonResponse.getJSONObject("wind");
                        double speed = jsonObjectWind.getDouble("speed");
                        double deg = jsonObjectWind.getDouble("deg");

                        JSONObject jsonObjectClouds = jsonResponse.getJSONObject("clouds");
                        String clouds = jsonObjectClouds.getString("all");




                        weather.setDescription(description);
                        weather.setTemperature(temp);
                        weather.setTempMax(temp_max);
                        weather.setTempMin(temp_min);
                        weather.setHum(humidity);
                        weather.setWindSpeed(speed);
                        weather.setWindDegree(deg);
                        weather.setCloudy(clouds);
                        weather.setIcon(icon);


                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }



                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            ivIcon.setVisibility(View.INVISIBLE);


                            textViewDescription.setText(weather.getDescription());
                            textViewTemperature.setText(weather.getTemperature() + " F");
                            textViewTemperatureMin.setText(weather.getTempMin() + " F");
                            textViewTemperatureMax.setText(weather.getTempMax() + " F");
                            textViewHumidity.setText(weather.getHum() + "%");
                            textViewWindSpeed.setText(weather.getWindSpeed()  + " miles/hr");
                            textViewWindDegree.setText(weather.getWindDegree() + " degrees");
                            textViewCloudiness.setText(weather.getCloudy() + "%");
                            Picasso.get().load("https://openweathermap.org/img/wn/" + weather.getIcon() + ".png").into(ivIcon);

                            ivIcon.setVisibility(View.VISIBLE);
                            textViewDescription.setVisibility(View.VISIBLE);
                            textViewTemperature.setVisibility(View.VISIBLE);
                            textViewTemperatureMin.setVisibility(View.VISIBLE);
                            textViewTemperatureMax.setVisibility(View.VISIBLE);
                            textViewHumidity.setVisibility(View.VISIBLE);
                            textViewWindSpeed.setVisibility(View.VISIBLE);
                            textViewWindDegree.setVisibility(View.VISIBLE);
                            textViewCloudiness.setVisibility(View.VISIBLE);

                        }
                    });
                } else {
                    ResponseBody responseBody = response.body();
                    String body = responseBody.string();
                    Log.d(TAG, "onResponse: " + body);
                }
            }
        });
    }

    void setTitles(){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewCityCurrent.setText(selectedData.getCity() + ", " + selectedData.getCountry());
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        //Current Weather
        getActivity().setTitle(R.string.currentWeatherTitle);
    }

    public interface ForecastListener {
        void onClickedForecast(Data.City clickedData);
    }

}